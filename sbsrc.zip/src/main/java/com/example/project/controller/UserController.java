package com.example.project.controller;
import com.example.project.EntityClass.User;
import com.example.project.repository.UserRepository;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class UserController {

    // standard constructors

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/users")
    public List<User> getUsers() {
        return (List<User>) userRepository.findAll();
    }

    @PostMapping("/users")
    void addUser(@RequestBody User user) {
        userRepository.save(user);
    }

    @PostMapping("/login")
    public User login(@RequestBody User user) {
        User temp = new User();
        temp = userRepository.findByUidAndPassword(user.getUid(), user.getPassword());

        if (temp.getUid().equals(user.getUid()) && temp.getPassword().equals(user.getPassword()))
        {
            return temp;
            }

        return temp;
    }

}
