package com.example.project.EntityClass;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {

    public User() {
    }

    public User(String name, String uid, String email, long phoneNo, String password, String confirmPassword) {
        this.name=name;
        this.uid=uid;
        this.email=email;
        this.phoneNo=phoneNo;
		this.password=password;
		this.confirmPassword=confirmPassword;
    }


    @GeneratedValue (strategy = GenerationType.AUTO)

    private long id;
    private  String name;
    @Id
    private String uid;
    private  String email;
    private long phoneNo;
	private String password;
	private String confirmPassword;
	private boolean status=true;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }

   public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
	
	   public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", uid='" + uid + '\'' +
                ", email='" + email + '\'' +
                ", phoneNo=" + phoneNo + 
                ", password=" + password + 
                ", confirmPassword=" + confirmPassword + 
                '}';
    }



// standard constructors / setters / getters / toString
}