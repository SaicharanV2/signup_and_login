import { User } from './user';

export class Uservo 
{
    id: number;
    name: string;
    uid:string;
    email: string;
    phoneNo:number;
    password:string;
    confirmPassword:string;    message:String;
    status:String;
}
