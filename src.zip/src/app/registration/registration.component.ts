import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PasswordValidation } from '../password-validation';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user-service.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

 
    user: User;
  showMsg: boolean=false;
   
    constructor(
       private route: ActivatedRoute, 
         private router: Router, 
           private userService: UserService,
          private formBuilder: FormBuilder,
          private fb: FormBuilder

          ) {
      this.user = new User();
    }
    registerForm: FormGroup;
      submitted = false;
  
    ngOnInit() 
    {
      this.registerForm = this.formBuilder.group({
          name: ['', [Validators.required,Validators.pattern(/^[a-zA-Z ]{0,16}$/)]],
          uid: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phoneNo:['',[ Validators.required,Validators.pattern(/^[0-9]{0,10}$/)]],
          password: ['',Validators.required],
          confirmPassword: ['',Validators.required]}, 
          {
            validator: PasswordValidation.MatchPassword // your validation method
          })
    }
    get f() { return this.registerForm.controls; }
  
  
    onSubmit() {
      this.submitted=true;
      // // stop here if form is invalid
       if (this.registerForm.invalid) 
      {
          return;
      }
      console.log(this.user.name);

       this.userService.save(this.user).subscribe(result => this.gotoUserList());
    }
   
     gotoUserList() {
      this.showMsg= true;
      // this.router.navigate(['/login']);
      console.log(this.user.name);
     }

     
  }


