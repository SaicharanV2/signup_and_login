import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PasswordValidation } from '../password-validation';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user-service.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

 
    user: User;
  status: number;
  message: string;
  newmessage: string;
  message2: string;
  showMsg: boolean;
  showMsg1: boolean;
  showMsg2: boolean;
  m: string;
   
    constructor(
       private route: ActivatedRoute, 
         private router: Router, 
           private userService: UserService,
          private formBuilder: FormBuilder,
          private fb: FormBuilder

          ) {
      this.user = new User();
    }
    registerForm: FormGroup;
      submitted = false;
  
    ngOnInit() 
    {
      this.registerForm = this.formBuilder.group({
          name: ['', [Validators.required,Validators.pattern(/^[a-zA-Z ]{0,16}$/)]],
          uid: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phoneNo:['',[ Validators.required,Validators.pattern(/^[0-9]{0,10}$/)]],
          password: ['',Validators.required],
          confirmPassword: ['',Validators.required]}, 
          {
            validator: PasswordValidation.MatchPassword // your validation method
          })

    }

    get f() { return this.registerForm.controls; }

    resetForm(value:any=undefined):void{
                    this.registerForm.reset(value);
                    (this as {submitted:boolean}).submitted=false;
    }

    onSubmit() {
      this.submitted=true;
      // // stop here if form is invalid
       if (this.registerForm.invalid) {
          return;
      }
      console.log(this.user.name);

       this.userService.save(this.user).subscribe((result: User) => 
         {
           let message='message'
         localStorage.setItem(message,result.message);
         this.m=localStorage.getItem('message');

         console.log(result.status);
         console.log(result.message);		

                   //if fails or success check.
                   if(result.status===1){
          
                console.log(this.user.name);
                this.showMsg= true;
                this.showMsg1= false;
                this.showMsg2= false;
                    this.resetForm();

              }
               if(result.status===2){
              console.log(result.message);
                this.showMsg1= true;
                this.showMsg= false;
                this.showMsg2= false;
                this.resetForm();
              }
               if(result.status===3){
                console.log(result.message);
                this.showMsg2= true;
                this.showMsg= false;
                this.showMsg1= false;
                this.resetForm();

                   }
                  });
                 
              }
                }
          
          
          