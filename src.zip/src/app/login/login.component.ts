import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // user: User;
  user: User;
  id: string;
  successFlag: boolean
  errorFlag: boolean
    constructor(
       private route: ActivatedRoute, 
         private router: Router, 
           private userService: UserService,

          ) {

      this.user = new User();
    }
      submitted = false;
  
    ngOnInit() 
    {
      
    }
    
    onLogin() 
    {
      
       this.userService.login(this.user).subscribe((res: User) => {
          if (res.status = true) {
            this.successFlag = true
            this.userService.loginStatus = true
            console.log(res.id);
            let name1='name1'
            localStorage.setItem(name1,res.name);

            let uid1='uid1'
            localStorage.setItem(uid1,res.uid);

            let phone=res.phoneNo.toString(10);
            let phone1='phone1'
            localStorage.setItem(phone1,phone);

            let email1='email1'
            localStorage.setItem(email1,res.email);

       this.router.navigate(['/welcome']);
          }
          else {
            this.errorFlag = true
            this.userService.loginStatus = false
          }
        }, err => {
          console.log(err)
          this.errorFlag = true
          this.userService.loginStatus = false
        })
    }
  
    initUser() {
      this.user = {
        id: 0,
        uid: '',
        password: '',
        name: '',
        email: '',
         phoneNo:0,
        confirmPassword:'',
        status:false
      }
    }

         
   
  }



