import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  constructor( private route: ActivatedRoute, 
    private router: Router, 
  ) { }
  ngOnInit() {

  }
  sname=localStorage.getItem('name1');
  semail=localStorage.getItem('email1');
  sphone=parseInt(localStorage.getItem('phone1'),10);
  suid=localStorage.getItem('uid1');
    onLogout(){
  this.router.navigate(['/login']);
  localStorage.clear();
}
}
