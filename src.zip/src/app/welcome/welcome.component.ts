import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  constructor() { }
  ngOnInit() {

  }
  sname=localStorage.getItem('name1');
  semail=localStorage.getItem('email1');
  sphone=parseInt(localStorage.getItem('phone1'),10);
  suid=localStorage.getItem('uid1');

}
