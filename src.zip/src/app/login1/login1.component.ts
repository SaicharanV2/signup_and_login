import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user-service.service';

@Component({
  selector: 'app-login1',
  templateUrl: './login1.component.html',
  styleUrls: ['./login1.component.css']
})
export class Login1Component implements OnInit {

  // user: User;
  user: User;
  successFlag: boolean
  errorFlag: boolean

   
    constructor(
       private route: ActivatedRoute, 
         private router: Router, 
           private userService: UserService,

          ) {

      this.user = new User();
    }
      submitted = false;
  
    ngOnInit() 
    {
      
    }
    
    onLogin() 
    {   
       this.userService.login(this.user).subscribe((res: User) => {
          if (res.status = true) {
            this.successFlag = true
            this.userService.loginStatus = true
            console.log(res.id);
            console.log(res.uid);
            console.log(res.name);
            console.log(res.password);
            console.log(res.email);

       this.router.navigate(['/welcome']);
          }
          else {
            this.errorFlag = true
            this.userService.loginStatus = false
          }
        }, err => {
          console.log(err)
          this.errorFlag = true
          this.userService.loginStatus = false
        })
    }
  
    initUser() {
      this.user = {
        id: 0,
        uid: '',
        password: '',
        name: '',
        email: '',
         phoneNo:0,
        confirmPassword:'',
        status:false
      }
    }

         
   
  }



