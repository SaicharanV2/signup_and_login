import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { User } from './user';
import { Observable } from 'rxjs';
 


const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};


@Injectable()
export class UserService {
  
  
  loginStatus: boolean
  currentUser: User


  constructor(private http: HttpClient) {
    this.loginStatus = false
  }
 
  public findAll(): Observable<User[]> {
    return this.http.get<User[]>('http://localhost:8080/users');
  }
 
  public save(user: User) {
    return this.http.post<User>('http://localhost:8080/users', user);
  }

  public login(user:User)
  {
    return this.http.post<User>('http://localhost:8080/login', user, httpOptions);

  }
}