import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import {UserListComponent} from './user-list/user-list.component';
import { Login1Component } from './login1/login1.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [

  {path:'registration', component:RegistrationComponent},
  { path: 'users', component: UserListComponent },
  { path: 'login', component: LoginComponent },
  { path: '', component: LoginComponent },
  { path: 'login1', component: Login1Component },
  { path: 'welcome', component: WelcomeComponent }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
