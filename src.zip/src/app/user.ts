export class User { id: number;
    name: string;
    uid:string;
    email: string;
    phoneNo:number;
    password:string;
    confirmPassword:string;
    status:boolean;
}
