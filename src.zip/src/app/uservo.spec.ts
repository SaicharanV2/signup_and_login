import { Uservo } from './uservo';

describe('Uservo', () => {
  it('should create an instance', () => {
    expect(new Uservo()).toBeTruthy();
  });
});
