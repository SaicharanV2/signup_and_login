import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  password: string | undefined;
  userid: string | undefined;
  id: any;
  isValid: boolean = true;
  islogged: boolean = false;
  loginform: any;
  submitted = false;
  userTestStatus: any;
  constructor(
    private fb: FormBuilder
  ) { }


  ngOnInit() {
    this.userTestStatus = [
      { "id": "0", "password": "Available" },
      { "id": "1", "password": "Ready" },
      { "id": "2", "password": "Started" }
    ];



  }

  onLogin() {
    let value = [];

    for (let i = 0; i < this.userTestStatus.length; i++) {
      if (this.userid === this.userTestStatus[i].id && this.password === this.userTestStatus[i].password) {

        value.push(true)
      }
    }
    if (value.includes(true)) {
      this.islogged = true
    }
    else {
      this.isValid = false;
    }
  }
}


