package com.example.project.repository;

import com.example.project.entityClass.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
    User findByUidAndPassword(String Uid, String Password);
    User findByUid(String Uid);
}


