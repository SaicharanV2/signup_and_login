package com.example.project.service;

import com.example.project.entityClass.User;
import com.example.project.repository.UserRepository;
import com.example.project.vo.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceClass implements UserService {
    @Autowired
    private  UserRepository userRepository;
    @Autowired
    UserService userService;

    @Override
    public ResponseVo saveUser(User user) {
        ResponseVo responseVo=new ResponseVo();
        User userdto=userRepository.findByUid(user.getUid());
         try {
             if (userdto == null) {
                 userRepository.save(user);
                 responseVo.setStatus(1);
                 responseVo.setMessage("Registration Sucessfull");
                 System.out.println(responseVo.getMessage());
                 System.out.println(responseVo.getStatus());
             } else{
                 responseVo.setStatus(2);
                 responseVo.setMessage("User Already exists");
                 System.out.println(responseVo.getMessage());
                 System.out.println(responseVo.getStatus());
             }
         }
        catch(Exception e){
            responseVo.setStatus(3);
            responseVo.setMessage("Registration Failed!! Please try again");
        }
		return responseVo;
}

    @Override
    public User login(User user) {
        User temp = new User();
        temp = userRepository.findByUidAndPassword(user.getUid(), user.getPassword());

        if (temp.getUid().equals(user.getUid()) && temp.getPassword().equals(user.getPassword())) {
            return temp;
        }
        else{

            System.out.println("invalid account credentials");
            return null;
        }
    }

    @Override
    public List<User> getUser() {
        return(List<User>)  userRepository.findAll();
    }

}
