package com.example.project.service;
import com.example.project.entityClass.User;
import com.example.project.vo.ResponseVo;

import java.util.List;

public interface UserService
{
    public abstract ResponseVo saveUser(User user);
    public abstract User login(User user);
    public abstract List<User> getUser();
}
