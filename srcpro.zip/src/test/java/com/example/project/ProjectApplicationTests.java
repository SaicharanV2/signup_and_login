package com.example.project;

import com.example.project.entityClass.User;
import com.example.project.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class ProjectApplicationTests {

    @Autowired
    private UserRepository userRepository2;


    @Test
    @DisplayName("Test for Login Method..")
    public void LogTest() {
        User user = new User("reddy", "9876", "saireddy@gmail.com", 11111, "abcd", "abcd");
        userRepository2.save(user);
        User userdummy = userRepository2.findByUid("9876");
        assertNotNull(user);
        assertEquals(userdummy.getName(), user.getName());
        assertEquals(userdummy.getPhoneNo(), user.getPhoneNo());
    }

    @Test
    @DisplayName("Test for saveUser Method..")
    public void regTest() {
        User user1 = new User("Sai Charan", "146055", "sai@gmail.com", 11111, "abcd", "abcd");
        userRepository2.save(user1);
        assertNotNull(user1);
        User temp = userRepository2.findByUid("146055");
        String name = temp.getName();
        String email = temp.getEmail();
        String password = temp.getPassword();
        String confirmPassword = temp.getConfirmPassword();
        String uid = temp.getUid();
        Long phone = temp.getPhoneNo();
        assertEquals("Sai Charan", name);
        assertEquals(11111, phone);
        assertEquals("sai@gmail.com", email);
        assertEquals("abcd", password);
        assertEquals("abcd", confirmPassword);
        assertEquals("146055", uid);
    }

    @Test
    @DisplayName("Test for getUser Method..")
    public void getUserTest() {
        User user2 = new User("Sai", "12345", "saisai@gmail.com", 1112211, "abcde", "abcde");
        User user3 = new User("Charan", "123", "charan@gmail.com", 12345, "abcd", "abcd");

        userRepository2.save(user2);
        userRepository2.save(user3);
        assertNotNull(userRepository2.findAll());
		System.out.println(userRepository2.count());
    }
}
